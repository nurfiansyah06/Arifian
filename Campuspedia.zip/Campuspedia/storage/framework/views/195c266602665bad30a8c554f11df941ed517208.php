<?php $__env->startSection('title','Data Siswa'); ?>
    


<?php $__env->startSection('container'); ?>

<br><br>
<div class="container">

        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
            <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>
  
      <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>
  
      <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-warning alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
      </div>
      <?php endif; ?>
  
      <?php if($message = Session::get('info')): ?>
        <div class="alert alert-info alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>
  
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <button type="button" class="close" data-dismiss="alert">×</button> 
          Please check the form below for errors
      </div>
      <?php endif; ?>
    
    <div class="card">
        <div class="card-body" style="grey" style="border-radius:10px">
<h1>Data Siswa Sebuah Sekolah</h1>
<br>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">No.Handphone</th>
            <th scope="col">Email</th>
            <th scope="col">Opsi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <th scope="row"><?php echo e(@$loop->iteration); ?></th>        
            <th scope="row"><?php echo e($users -> nama); ?></th>        
            <th scope="row"><?php echo e($users -> hp); ?></th>        
            <th scope="row"><?php echo e($users -> email); ?></th>                        
            <th scope="row">
                <a href="<?php echo e(url("siswa/edit/{$users->id}")); ?>" class="badge badge-success">Edit</a>    
                <a href="<?php echo e(url("siswa/hapus/{$users->id}")); ?>" class="badge badge-danger">Hapus</a>        
            </th>        
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>